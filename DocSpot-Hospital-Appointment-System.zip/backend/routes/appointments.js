
const express = require("express");
const router = express.Router();

let appointments = [];

router.get("/", (req, res) => {
  res.json(appointments);
});

router.post("/", (req, res) => {
  const newAppointment = {
    id: Date.now(),
    ...req.body
  };
  appointments.push(newAppointment);
  res.status(201).json(newAppointment);
});

router.delete("/:id", (req, res) => {
  appointments = appointments.filter(
    (a) => a.id !== parseInt(req.params.id)
  );
  res.json({ message: "Appointment deleted" });
});

module.exports = router;
