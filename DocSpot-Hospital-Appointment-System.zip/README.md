
# DocSpot - Seamless Appointment Booking for Health

## How to Run

### Backend
cd backend
npm install
npm start

### Frontend
cd frontend
npm install
npm start

Open http://localhost:3000
