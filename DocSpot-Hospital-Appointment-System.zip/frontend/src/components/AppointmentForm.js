
import React, { useState } from "react";
import axios from "axios";

function AppointmentForm() {
  const [form, setForm] = useState({
    name: "",
    doctor: "",
    date: "",
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.post("http://localhost:5000/api/appointments", form);
    window.location.reload();
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <h2>Book Appointment</h2>
      <input name="name" placeholder="Patient Name" onChange={handleChange} required />
      <input name="doctor" placeholder="Doctor Name" onChange={handleChange} required />
      <input type="date" name="date" onChange={handleChange} required />
      <button type="submit">Book</button>
    </form>
  );
}

export default AppointmentForm;
