
import React from "react";

function Navbar() {
  return (
    <nav className="navbar">
      <h1>DocSpot</h1>
      <p>Seamless Appointment Booking for Health</p>
    </nav>
  );
}

export default Navbar;
