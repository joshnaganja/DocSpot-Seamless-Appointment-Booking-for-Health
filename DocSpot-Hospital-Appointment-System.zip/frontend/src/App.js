
import React from "react";
import Navbar from "./components/Navbar";
import AppointmentForm from "./components/AppointmentForm";
import AppointmentList from "./components/AppointmentList";

function App() {
  return (
    <div>
      <Navbar />
      <div className="container">
        <AppointmentForm />
        <AppointmentList />
      </div>
    </div>
  );
}

export default App;
